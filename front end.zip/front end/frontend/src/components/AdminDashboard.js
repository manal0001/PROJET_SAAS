import React, { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';
import './AdminDashboard.css';
import { getAllBooks, createBook, deleteBook, updateBook } from '../services/bookService';
import { getAllUsers, createUser, deleteUser, updateUser } from '../services/userService';

const AdminDashboard = () => {
  const [books, setBooks] = useState([]);
  const [users, setUsers] = useState([]);
  const [newBook, setNewBook] = useState({ titre: '', auteur: '', anneePublication: '', genre: '', resume: '', disponible: true });
  const [newUser, setNewUser] = useState({ nom: '', email: '', motDePasse: '', role: '' });
  const [updatingBook, setUpdatingBook] = useState(null);
  const [updatingUser, setUpdatingUser] = useState(null);

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const { data } = await getAllBooks();
        setBooks(data);
      } catch (error) {
        console.error(error);
      }
    };

    const fetchUsers = async () => {
      try {
        const { data } = await getAllUsers();
        setUsers(data);
      } catch (error) {
        console.error(error);
      }
    };

    fetchBooks();
    fetchUsers();
  }, []);

  const handleCreateBook = async () => {
    try {
      await createBook(newBook);
      setNewBook({ titre: '', auteur: '', anneePublication: '', genre: '', resume: '', disponible: true });
      const { data } = await getAllBooks();
      setBooks(data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteBook = async (id) => {
    try {
      await deleteBook(id);
      setBooks(books.filter(book => book.id !== id));
    } catch (error) {
      console.error(error);
    }
  };

  const handleCreateUser = async () => {
    try {
      await createUser(newUser);
      setNewUser({ nom: '', email: '', motDePasse: '', role: '' });
      const { data } = await getAllUsers();
      setUsers(data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleDeleteUser = async (id) => {
    try {
      await deleteUser(id);
      setUsers(users.filter(user => user.id !== id));
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateBook = async () => {
    try {
      await updateBook(updatingBook.id, updatingBook);
      const { data } = await getAllBooks();
      setBooks(data);
      setUpdatingBook(null);
    } catch (error) {
      console.error(error);
    }
  };

  const handleUpdateUser = async () => {
    try {
      await updateUser(updatingUser.id, updatingUser);
      const { data } = await getAllUsers();
      setUsers(data);
      setUpdatingUser(null);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = () => {
    // Rediriger vers la page de connexion
    // Peut-être utiliser une fonction fournie par votre routeur ou simplement changer manuellement l'URL
  };

  return (
    <div className="admin-dashboard">
      <h2>Admin Dashboard</h2>
      <NavLink to="/login" onClick={handleLogout}>Logout</NavLink>

      <h3>Books</h3>
      <ul>
        {books.map(book => (
          <li key={book.id}>
            {updatingBook && updatingBook.id === book.id ? (
              <div>
                <input type="text" value={updatingBook.titre} onChange={(e) => setUpdatingBook({ ...updatingBook, titre: e.target.value })} />
                <input type="text" value={updatingBook.auteur} onChange={(e) => setUpdatingBook({ ...updatingBook, auteur: e.target.value })} />
                <input type="number" value={updatingBook.anneePublication} onChange={(e) => setUpdatingBook({ ...updatingBook, anneePublication: e.target.value })} />
                <input type="text" value={updatingBook.genre} onChange={(e) => setUpdatingBook({ ...updatingBook, genre: e.target.value })} />
                <input type="text" value={updatingBook.resume} onChange={(e) => setUpdatingBook({ ...updatingBook, resume: e.target.value })} />
                <button onClick={handleUpdateBook}>Update</button>
              </div>
            ) : (
              <div>
                {book.titre} by {book.auteur} <button onClick={() => setUpdatingBook(book)}>Edit</button> <button onClick={() => handleDeleteBook(book.id)}>Delete</button>
              </div>
            )}
          </li>
        ))}
      </ul>
      <h3>Add New Book</h3>
      <input type="text" placeholder="Title" value={newBook.titre} onChange={(e) => setNewBook({ ...newBook, titre: e.target.value })} />
      <input type="text" placeholder="Author" value={newBook.auteur} onChange={(e) => setNewBook({ ...newBook, auteur: e.target.value })} />
      <input type="number" placeholder="Year" value={newBook.anneePublication} onChange={(e) => setNewBook({ ...newBook, anneePublication: e.target.value })} />
      <input type="text" placeholder="Genre" value={newBook.genre} onChange={(e) => setNewBook({ ...newBook, genre: e.target.value })} />
      <input type="text" placeholder="Summary" value={newBook.resume} onChange={(e) => setNewBook({ ...newBook, resume: e.target.value })} />
      <button onClick={handleCreateBook}>Add Book</button>

      <h3>Users</h3>
      <ul>
        {users.map(user => (
          <li key={user.id}>
            {updatingUser && updatingUser.id === user.id ? (
              <div>
                <input type="text" value={updatingUser.nom} onChange={(e) => setUpdatingUser({ ...updatingUser, nom: e.target.value })} />
                <input type="email" value={updatingUser.email} onChange={(e) => setUpdatingUser({ ...updatingUser, email: e.target.value })} />
                <input type="password" value={updatingUser.motDePasse} onChange={(e) => setUpdatingUser({ ...updatingUser, motDePasse: e.target.value })} />
                <input type="text" value={updatingUser.role} onChange={(e) => setUpdatingUser({ ...updatingUser, role: e.target.value })} />
                <button onClick={handleUpdateUser}>Update</button>
              </div>
            ) : (
              <div>
                {user.nom} ({user.email}) <button onClick={() => setUpdatingUser(user)}>
                Edit</button> <button onClick={() => handleDeleteUser(user.id)}>Delete</button>
              </div>
            )}
          </li>
        ))}
      </ul>
      <h3>Add New User</h3>
      <input type="text" placeholder="Name" value={newUser.nom} onChange={(e) => setNewUser({ ...newUser, nom: e.target.value })} />
      <input type="email" placeholder="Email" value={newUser.email} onChange={(e) => setNewUser({ ...newUser, email: e.target.value })} />
      <input type="password" placeholder="Password" value={newUser.motDePasse} onChange={(e) => setNewUser({ ...newUser, motDePasse: e.target.value })} />
      <select value={newUser.role} onChange={(e) => setNewUser({ ...newUser, role: e.target.value })}>
        <option value="utilisateur">Utilisateur</option>
        <option value="administrateur">Administrateur</option>
      </select>
      <button onClick={handleCreateUser}>Add User</button>
    </div>
  );
};

export default AdminDashboard;

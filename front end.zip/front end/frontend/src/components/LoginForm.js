import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { login } from '../services/authService';
import './LoginForm.css';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await login({ email, motDePasse: password });
      const { token, role } = response.data;
      console.log("Login Response:", response.data); // Ensure role is in the response
      console.log("Role:", role); // Log the role
      localStorage.setItem('token', token);
      if (role === 'administrateur') {
        console.log("Navigating to admin dashboard"); // Add this line
        navigate('/admin-dashboard');
      } else {
        console.log("Navigating to user dashboard"); // Add this line
        navigate('/user-dashboard');
      }
    } catch (error) {
      console.error("Login Error:", error.response ? error.response.data : error.message); // Add detailed error logging
    }
  };
  
  
  return (
    <div className="login-form">
      <form onSubmit={handleSubmit}>
        <h2>Login</h2>
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <button type="submit">Login</button>
      </form>
      <p>
        Don't have an account? <Link to="/register">Register</Link>
      </p>
    </div>
  );
};

export default LoginForm;

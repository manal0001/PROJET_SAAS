import React, { useEffect, useState } from 'react';
import { getAllBooks, borrowBook, returnBook, getBorrowedBooks } from '../services/bookService';
import { useNavigate } from 'react-router-dom';
import './UserDashboard.css'; // Importation du fichier CSS

const UserDashboard = () => {
  const [books, setBooks] = useState([]);
  const [borrowedBooks, setBorrowedBooks] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchBooks = async () => {
      try {
        const { data } = await getAllBooks();
        setBooks(data);
      } catch (error) {
        console.error('Error fetching all books:', error);
      }
    };

    const fetchBorrowedBooks = async () => {
      try {
        const { data } = await getBorrowedBooks();
        setBorrowedBooks(data);
      } catch (error) {
        console.error('Error fetching borrowed books:', error);
      }
    };

    fetchBooks();
    fetchBorrowedBooks();
  }, []);

  const handleBorrowBook = async (id) => {
    try {
      console.log(`Attempting to borrow book with id: ${id}`);
      await borrowBook(id);
      console.log('Book borrowed successfully');
      const { data: booksData } = await getAllBooks();
      setBooks(booksData);
      const { data: borrowedBooksData } = await getBorrowedBooks();
      setBorrowedBooks(borrowedBooksData);
    } catch (error) {
      console.error(`Error borrowing book with id ${id}:`, error.response ? error.response.data : error.message);
    }
  };

  const handleReturnBook = async (loanId) => {
    try {
      console.log(`Attempting to return book with loan id: ${loanId}`);
      await returnBook(loanId);
      console.log('Book returned successfully');
      const { data: booksData } = await getAllBooks();
      setBooks(booksData);
      const { data: borrowedBooksData } = await getBorrowedBooks();
      setBorrowedBooks(borrowedBooksData);
    } catch (error) {
      console.error(`Error returning book with loan id ${loanId}:`, error.response ? error.response.data : error.message);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    navigate('/login');
  };

  return (
    <div className="user-dashboard user-dashboard-background">
      <h2>User Dashboard</h2>
      <button onClick={handleLogout}>Logout</button>
      <h3>All Books</h3>
      <ul>
        {books.map(book => (
          <li key={book.id}>
            <strong>{book.titre}</strong> by {book.auteur} ({book.disponible ? 'Available' : 'Not Available'})
            <button onClick={() => handleBorrowBook(book.id)} disabled={!book.disponible}>Borrow</button>
            <button onClick={() => handleReturnBook(book.loanId)} disabled={book.disponible}>Return</button>
            <button onClick={() => alert(JSON.stringify(book, null, 2))}>Details</button>
          </li>
        ))}
      </ul>

      <h3>Borrowed Books</h3>
      <ul>
        {borrowedBooks.map(book => (
          <li key={book.id}>
            <strong>{book.titre}</strong> by {book.auteur}
            <button onClick={() => handleReturnBook(book.loanId)}>Return</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserDashboard;

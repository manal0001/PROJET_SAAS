import axios from 'axios';

export const register = async (user) => {
  return await axios.post('/api/users/register', user);
};

export const login = async (credentials) => {
  return await axios.post('/api/users/login', credentials);
};

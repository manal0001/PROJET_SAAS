// bookService.js
import axios from 'axios';

export const getAllBooks = async () => {
  return await axios.get('/api/books');
};

export const createBook = async (book) => {
  return await axios.post('/api/books', book);
};

export const deleteBook = async (id) => {
  return await axios.delete(`/api/books/${id}`);
};

export const updateBook = async (id, book) => {
  return await axios.put(`/api/books/${id}`, book);
};

export const borrowBook = async (id) => {
  return await axios.post(`/api/loans/borrow`, { bookId: id }, {
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  });
};

export const returnBook = async (loanId) => {
  return await axios.post(`/api/loans/return`, { loanId }, {
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  });
};

export const getBorrowedBooks = async () => {
  return await axios.get('/api/loans/borrowed', {
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  });
};
